/** Automatically generated file. DO NOT MODIFY */
package com.gan.quickindex;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}